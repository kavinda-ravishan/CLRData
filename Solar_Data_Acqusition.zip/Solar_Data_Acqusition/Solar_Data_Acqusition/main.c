/*
 * Solar_Data_Acqusition.c
 *
 * Created: 11-Dec-18 9:22:22
 * Author : msmnafly
 */ 
#define F_CPU 16000000
#include <avr/io.h>
//#include <avr/interrupt.h>
#include <util/delay.h>

/*defining values for ADC*/
#define ADC_ENABLE 					ADCSRA |= (1<<ADEN)
#define ADC_DISABLE 				ADCSRA &= 0x7F
#define ADC_START_CONVERSION		ADCSRA |= (1<<ADSC)
/**********************************************************************/

/*defining values for USART - Serial comm.*/
#define BAUD 9600
#define MYUBRR ((F_CPU/16/BAUD)-1) //ubrr value for Baud rate 
/**********************************************************************/
//variables
unsigned char current[4];
unsigned char voltage[4];

/*void ADC_init(void);
unsigned int ADC_read(unsigned char);
void readCurrent(unsigned char);
void readVoltage(unsigned char);*/

void ADC_init(void)
{
	ADC_DISABLE;
	ADCSRA |= 0x47; //pre-scaler:128, single conversion mode
	ADC_ENABLE;
}

unsigned int ADC_read(unsigned char adc_input_pin)
{
	/*clear the channel bits and set the new channel 
	*External V_ref, right adjust result, set channel*/
	 ADMUX = (ADMUX & 0xF0)| adc_input_pin;
	 
	 //Start the AD conversion
	 ADCSRA |= (1<<ADSC);
	 
	 //Wait for the AD conversion to complete
	 while(ADCSRA & (1<<ADSC));
	 
	 //return result
	 return ADC; //ADCW
}

void readVoltage() 
{
	/*connected to the normally off*/
	PORTB &= 0B11111110;
	_delay_ms(500);
	/********************************************************/
	/*defining variables*/
	unsigned int value;
	float volt = 0;
	/********************************************************/
	//read 100 times and take average for high precision
	for(int i = 0; i < 100; i++){
	/*Initiate the input
	*Use A0 pin to get current measurement*/
	value = ADC_read(0);
	//calculating voltage
	volt = volt + (value * 25.0)/1023.0;
	//to save in array
	}
	volt = volt/100;
	value = (unsigned int)(volt * 1000);
	
	value = value / 10;
	voltage[3] = (value % 10) | 0x30;
	value = value / 10;
	voltage[2] = (value % 10) | 0x30;
	value = value / 10;
	voltage[1] = (value % 10) | 0x30;
	value = value / 10;
	voltage[0] = value | 0x30;
	
	
}
void readCurrent()
{
	/*The current sensor is connected with always on
	*Hence the digital output is 1*/
	PORTB |= 0B00000001;
	_delay_ms(500);
	/*Initiate the input pin
	*Use A1 pin to get voltage measurement*/
	unsigned int mVperAmp = 185.0; // use 100 for 20A Module and 66 for 30A Module
	unsigned int value;
	unsigned int ACSoffset = 2500.0;
	float volt;
	float Amps = 0;
	
	/*converting analog value into voltage 
	*and voltage into Amps*/
	for(int i = 0; i < 100; i++){
	value = ADC_read(1);
	volt = (value / 1023.0) * 5000.0; // Gets you mV
	Amps = Amps + ((volt - ACSoffset) / mVperAmp);
	}
	Amps = Amps/100;
	//to save in array
	value = (unsigned int)(Amps*1000);
	/*********************************************/
	/*Store in an array*/
	value = value / 10;
	current[3] = (value % 10) | 0x30;
	value = value / 10;
	current[2] = (value % 10) | 0x30;
	value = value / 10;
	current[1] = (value % 10) | 0x30;
	value = value / 10;
	current[0] = value | 0x30;
}

/******************************************************************************/
/* Functions regarding USART*/

void init_usart(unsigned int ubrr)
{
	/*Set baud rate*/
	UBRR0H = (unsigned char)(ubrr>>8) ; //set baud rate lo
	UBRR0L = (unsigned char)ubrr; //set baud rate hi
	/*Enable and transmitter*/
	UCSR0B = (1<<TXEN0);
	/*Set frame format: 8data, 1stop bits*/
	UCSR0C = (3<<UCSZ00);
}

void USART_Transmit(unsigned char data){
	/*wait for empty transmit buffer*/
	while (!(UCSR0A & (1<<UDRE0)));
	/*Put data into buffer, sends the data*/
	UDR0 = data;
}	
/****************************************************************************/

void transmit()
{
	for (int i=0; i<4 ;i++)
	{
		//Transmit the array
		USART_Transmit(voltage[i]);
	}
	for (int i=0; i<4 ;i++)
	{
		//Transmit the array
		USART_Transmit(current[i]);
	}
	//New line
	USART_Transmit(0x0A);
	USART_Transmit(0x0D);
}

int main(void)
{
	DDRB |= 0B00000001;		//defining the output for relay
	init_usart(MYUBRR);		
	ADC_init();
    while (1) 
    {
		readCurrent();
		_delay_ms(1000);
		readVoltage();
		_delay_ms(1000);
		transmit();
		
    }
	return 0;
}

